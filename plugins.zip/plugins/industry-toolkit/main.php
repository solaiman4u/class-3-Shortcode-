<?php

/*
Plugin Name: Industry Toolkit
Plugin URI: http://wordpress.org/plugins/industry/
Description: This is not just a plugin, This plugin for industry  theme.
Author: Solaiman
Version: 1.0
Author URI: http://rrf.com/
*/

function google_map($atts, $content = null){

	$size = shortcode_atts( array(
		'width'=> 600,
		'height'=> 450,
		'title'=> '',

	), $atts);

	if(is_user_logged_in()){
		$map = '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7296.990755396662!2d90.4046694250154!3d23.872046449140388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c43247fc17f3%3A0xbbc89db063a4bf7d!2sDewanpara%2C+Dhaka+1230!5e0!3m2!1sen!2sbd!4v1519274665033" width="'.$size['width'].'" height="'.$size['height'].'" frameborder="0" style="border:0" allowfullscreen></iframe>';
	
	}else{
		$map = '<h1>Hay man please logged in your account</h1>';
	}

	if(!empty($size['title']) && is_user_logged_in()){
		$map .= ''.$size['title'].'';
	}else{
		$map .= '';
	}

	return $map;
}

add_shortcode('gmap','google_map');
